# README FIRST - Report Factory v2.1 Claude Code Package

This ZIP contains the complete v2.1 instruction package for Claude Code.

Use the top-level files first:

1. CLAUDE.md
2. PRD.md
3. docs/migration/CLAUDE_CODE_AUTO_MODE_PROMPT.v2.1.md
4. docs/migration/IMPLEMENTATION_PLAN.v2.1.md
5. docs/migration/ENTERPRISE_ANALYTICS_ADDENDUM.v2.1.md
6. docs/migration/MIGRATION_CHECKLIST.v2.1.md

## Simple instruction to paste into Claude Code

Please upgrade my existing Report Factory app safely using this v2.1 package. Read CLAUDE.md and PRD.md first, then follow docs/migration/CLAUDE_CODE_AUTO_MODE_PROMPT.v2.1.md, IMPLEMENTATION_PLAN.v2.1.md, ENTERPRISE_ANALYTICS_ADDENDUM.v2.1.md, and MIGRATION_CHECKLIST.v2.1.md. I am not technical, so do the work in auto mode. Do not rewrite everything. Do not delete existing working features. Keep old mode working behind feature flags. Implement DuckDB Medallion Architecture, Gold layer, semantic data modeling, enterprise multi-fact reporting, complex join validation, governed KPI lineage, KPI comparison engine, kpi_by_dimension, kpi_correlation, target_vs_actual, top_bottom_segments, variance_analysis, benchmark_gap, dashboard recommendations, and Gold dashboard safely.
