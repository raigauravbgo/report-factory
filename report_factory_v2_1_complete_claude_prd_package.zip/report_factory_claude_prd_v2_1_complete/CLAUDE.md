# CLAUDE.md v2.1: Report Factory Safe Enterprise Analytics Migration

## Role

You are Claude Code acting as a senior full-stack engineer, data platform architect, analytics engineer, and migration specialist.

Your task is to safely upgrade the existing Report Factory application without breaking the current working app.

## Main principle

Preserve what works. Add the new DuckDB Medallion, Gold reporting, semantic modeling, KPI comparison, and LiteLLM architecture beside the old architecture first. Switch defaults only after verification.

## Non-negotiable safety rules

- Do not rewrite the entire application.
- Do not delete existing routes, pages, services, or SQLite metadata tables.
- Do not break the current upload, KPI selection, data modeling, recipe, or dashboard flow.
- Do not replace the existing dashboard before the new Gold dashboard is verified.
- Do not hardcode LLM providers or model names in business logic.
- Do not create new direct OpenAI SDK or Anthropic SDK calls.
- Do not make the new dashboard read directly from Bronze, Silver, raw uploaded files, pandas staging, or SQLite staging tables.
- Do not perform destructive migrations without backups.
- Keep all new functionality behind feature flags first.

## Required feature flags

Add and use these flags:

```env
USE_DUCKDB_MEDALLION=false
USE_GOLD_DASHBOARD=false
USE_ENTERPRISE_SEMANTIC_MODEL=false
USE_MULTI_KPI_COMPARISON=false
LLM_PROVIDER=mock
LLM_MODEL=mock
DUCKDB_STORAGE_PATH=storage/duckdb
UPLOAD_STORAGE_PATH=storage/uploads
EXPORT_STORAGE_PATH=storage/exports
```

When flags are false, the existing app behavior must continue working.

## Required target architecture

```text
Upload files
  -> DuckDB session
  -> Bronze raw tables
  -> Silver cleaned/profiled tables
  -> Validated semantic model
  -> Enterprise multi-fact model
  -> KPI mapping and validation
  -> KPI comparison engine
  -> DuckDB Gold reporting tables
  -> Gold dashboard
  -> Excel/PPTX export
  -> Governed KPI lineage and review queue
```

## Required DuckDB Medallion Architecture

DuckDB is the analytical engine for uploaded datasets in the new flow.

SQLite may remain for app metadata, users, recipes, review queue, and legacy staging metadata, but analytical reporting tables in the new flow must live in DuckDB.

Each dataset must have its own DuckDB database:

```text
storage/duckdb/{dataset_id}/report_factory.duckdb
```

## Required backend folders

Create or update:

```text
backend/services/duckdb/
backend/services/semantic/
backend/services/analytics/
backend/services/ai/
backend/services/exports/
```

## Required DuckDB services

Implement:

```text
backend/services/duckdb/duckdb_manager.py
backend/services/duckdb/bronze_service.py
backend/services/duckdb/silver_service.py
backend/services/duckdb/gold_service.py
backend/services/duckdb/lineage_service.py
backend/services/duckdb/query_logger.py
```

## Required semantic data modeling services

Implement or upgrade:

```text
backend/services/semantic/semantic_model_service.py
backend/services/semantic/fact_dimension_detector.py
backend/services/semantic/relationship_detector.py
backend/services/semantic/grain_detector.py
backend/services/semantic/join_validator.py
backend/services/semantic/multi_fact_modeler.py
backend/services/semantic/semantic_contract_validator.py
```

The semantic model must support:

- Fact tables
- Dimension tables
- Primary keys
- Foreign keys
- Date dimensions
- Table grain
- Metric grain
- Join paths
- Complex joins
- Multi-hop joins
- Many-to-many risk detection
- Row multiplication detection
- Conformed dimensions
- Enterprise multi-fact reporting
- Risky relationship review flags
- Validated semantic contracts before Gold materialization

## Required KPI comparison engine

Implement:

```text
backend/services/analytics/kpi_comparison_engine.py
backend/services/analytics/kpi_by_dimension.py
backend/services/analytics/kpi_correlation.py
backend/services/analytics/target_vs_actual.py
backend/services/analytics/top_bottom_segments.py
backend/services/analytics/variance_analysis.py
backend/services/analytics/benchmark_gap.py
backend/services/analytics/dashboard_recommendation_engine.py
```

The engine must support all selected KPIs, not only the first two.

Required outputs:

```text
kpi_by_dimension
kpi_correlation
target_vs_actual
top_bottom_segments
variance_analysis
benchmark_gap
dashboard_recommendations
multi_kpi_comparison_matrix
```

## Required Gold layer reporting objects

Gold must be materialized in DuckDB and must be the only source for the new dashboard and exports.

Required Gold objects:

```text
gold_kpi_results
gold_dashboard_dataset
gold_kpi_comparison_matrix
gold_dimension_breakdowns
gold_kpi_correlations
gold_target_vs_actual
gold_top_bottom_segments
gold_variance_analysis
gold_benchmark_gap
gold_dashboard_recommendations
gold_validation_summary
gold_export_dataset
gold_lineage_map
```

## Required governed KPI lineage

Every KPI result must be traceable to:

- KPI ID/name
- Formula used
- Source table(s)
- Source column(s)
- Bronze table(s)
- Silver table(s)
- Gold table/view
- Applied filters
- Join path
- Grain
- Validation status
- Warnings or review flags

Add lineage persistence using DuckDB tables and/or existing SQLite metadata tables.

## Required endpoints

Add new endpoints first. Keep old endpoints working.

```text
POST /api/medallion/{dataset_id}/bronze
POST /api/medallion/{dataset_id}/silver
POST /api/medallion/{dataset_id}/gold
GET  /api/semantic/{dataset_id}/model
POST /api/semantic/{dataset_id}/validate
GET  /api/analytics/{dataset_id}/kpi-comparison
GET  /api/dashboard/gold/{dataset_id}
GET  /api/dashboard/gold/{dataset_id}/recommendations
GET  /api/exports/{dataset_id}/excel
GET  /api/exports/{dataset_id}/pptx
GET  /api/lineage/{dataset_id}/kpi/{kpi_id}
```

Endpoint names may follow existing project conventions, but behavior must be implemented.

## Required LLM architecture

All new LLM calls must go through LiteLLM abstraction.

Implement:

```text
backend/services/ai/litellm_client.py
backend/services/ai/mock_llm_client.py
backend/services/ai/prompt_registry.py
```

Supported providers:

```text
mock
openai/gpt-4o-mini
anthropic/claude-sonnet-4-20250514
```

No new direct OpenAI SDK or Anthropic SDK calls.

## Required export services

Implement exports from Gold only:

```text
backend/services/exports/excel_export_service.py
backend/services/exports/pptx_export_service.py
```

Save exports under:

```text
storage/exports/{dataset_id}/
```

## Migration sequence

1. Backup current docs and create migration docs.
2. Add settings and feature flags.
3. Add required dependencies: duckdb, litellm, python-pptx, openpyxl, rapidfuzz if missing.
4. Add DuckDB manager and session handling.
5. Add Bronze ingestion for CSV and every Excel sheet.
6. Add Silver cleaning, typing, profiling, and lineage.
7. Add semantic data modeling services.
8. Add enterprise multi-fact reporting support.
9. Add complex join validation and row multiplication checks.
10. Add KPI validation and governed KPI lineage.
11. Add KPI comparison engine.
12. Add Gold materialization.
13. Add Gold dashboard endpoint.
14. Add dashboard recommendation engine.
15. Add Excel and PPTX exports from Gold.
16. Add LiteLLM abstraction and mock provider.
17. Add tests and smoke tests.
18. Verify old mode and new mode.
19. Provide final completion report.

## Acceptance checks Claude Code must run

- Existing legacy upload/dashboard still works with flags false.
- DuckDB database is created per dataset.
- Bronze tables are created per CSV and per Excel sheet.
- Silver tables are created with clean names, inferred types, profile metadata, and lineage.
- Semantic model detects facts, dimensions, keys, grains, join paths, and conformed dimensions.
- Complex joins are validated for many-to-many and row multiplication risk.
- Multi-fact reporting works when multiple fact tables share conformed dimensions.
- KPI comparison works for all selected KPIs.
- kpi_by_dimension works.
- kpi_correlation works where statistically valid.
- target_vs_actual works when target fields exist.
- top_bottom_segments works.
- variance_analysis works.
- benchmark_gap works when benchmark fields exist.
- Dashboard recommendations are generated.
- Gold dashboard reads only from Gold.
- Excel and PPTX exports read only from Gold.
- KPI lineage is queryable.
- LiteLLM mock mode works without external API keys.

## Completion report required

At the end, report:

- What changed
- New files created
- Existing files modified
- How to run legacy mode
- How to run DuckDB mode
- How to test dashboard and exports
- Which acceptance checks passed
- Any issues not completed
