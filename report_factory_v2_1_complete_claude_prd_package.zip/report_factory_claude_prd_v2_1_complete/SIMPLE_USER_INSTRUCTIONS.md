# Simple User Instructions

1. Unzip this package.
2. Open your Report Factory project in Claude Code.
3. Add/copy these files into your project.
4. Give Claude Code this instruction:

Please read CLAUDE.md and PRD.md first. Then follow the v2.1 migration files in docs/migration. Upgrade my app safely in auto mode. Do not delete working features. Use feature flags first. Implement DuckDB Medallion, Gold dashboard, semantic data modeling, enterprise multi-fact reporting, governed KPI lineage, KPI comparison engine, exports, and LiteLLM.

5. Let Claude Code work step by step.
6. Ask it to run the checklist before saying the work is complete.
