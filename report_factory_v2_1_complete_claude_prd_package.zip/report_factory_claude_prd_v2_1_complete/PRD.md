# Report Factory PRD v2.1: DuckDB Medallion + Enterprise KPI Analytics Migration

## Product goal

Upgrade Report Factory from a prototype reporting application into a safe, reliable, enterprise-grade, multi-file, multi-fact, multi-KPI reporting platform.

The upgraded application must support uploaded business datasets, DuckDB Medallion Architecture, validated semantic data modeling, enterprise multi-fact reporting, governed KPI lineage, advanced KPI comparison, Gold-layer dashboard reporting, and Gold-based Excel/PPTX exports.

## Non-technical summary

A user should be able to upload CSV/Excel files and the application should automatically understand the data, build a safe reporting model, suggest useful KPIs, calculate multiple KPIs, compare KPIs across dimensions, identify top/bottom performance, show target/benchmark gaps, recommend dashboard views, and generate Excel/PPTX reports without requiring manual SQL work.

## Current application status

The current application already has:

- Upload flow
- Profiling flow
- Schema mapping flow
- Data modeling flow
- KPI selection flow
- Dashboard flow
- Some AI/agent support
- SQLite-based metadata and staging behavior

The current application does not yet fully have:

- DuckDB Medallion Architecture
- Bronze/Silver/Gold analytical layers
- Gold-only dashboard
- Enterprise semantic data model
- Enterprise multi-fact reporting
- Complex join governance
- Governed KPI lineage
- Advanced cross-KPI comparison engine
- Dashboard recommendation engine
- Gold-based Excel/PPTX export
- LiteLLM provider abstraction

## Target architecture

```text
Upload files
  -> DuckDB session
  -> Bronze raw tables
  -> Silver cleaned/profiled tables
  -> Validated semantic model
  -> Enterprise multi-fact model
  -> KPI mapping and validation
  -> KPI comparison engine
  -> Gold reporting tables
  -> Gold dashboard / Excel / PPTX / Narrative
  -> Governed lineage and review queue
```

## Core requirement 1: DuckDB Medallion Architecture

The application must use DuckDB as the analytical engine for uploaded datasets in the new flow.

SQLite may remain for application metadata, but analytical reporting tables must move to DuckDB.

### DuckDB session

Each dataset/upload group must have its own DuckDB database:

```text
storage/duckdb/{dataset_id}/report_factory.duckdb
```

### Bronze layer

Bronze stores raw uploaded data.

Rules:

- One Bronze table per CSV file.
- One Bronze table per Excel sheet.
- Do not apply business transformations.
- Preserve raw columns.
- Add ingestion metadata.
- Track source filename, sheet name, row count, column count, ingestion timestamp, and ingestion status.

### Silver layer

Silver stores cleaned, typed, profiled data.

Rules:

- Normalize column names.
- Infer data types.
- Profile columns.
- Detect likely keys.
- Detect categorical, date, numeric, boolean, ID, measure, and text columns.
- Preserve lineage to Bronze.
- Prepare tables for semantic modeling.

### Gold layer

Gold stores validated reporting outputs.

Rules:

- Dashboard must read from Gold only in the new flow.
- Exports must read from Gold only in the new flow.
- Gold must fail clearly when validation fails.
- Gold must preserve governed KPI lineage.
- Gold must contain reusable reporting datasets, not only temporary calculations.

Required Gold objects:

```text
gold_kpi_results
gold_dashboard_dataset
gold_kpi_comparison_matrix
gold_dimension_breakdowns
gold_kpi_correlations
gold_target_vs_actual
gold_top_bottom_segments
gold_variance_analysis
gold_benchmark_gap
gold_dashboard_recommendations
gold_validation_summary
gold_export_dataset
gold_lineage_map
```

## Core requirement 2: Semantic data modeling

The application must create a validated semantic model from Silver tables before Gold is created.

The semantic model must detect and validate:

- Fact tables
- Dimension tables
- Primary keys
- Foreign keys
- Date dimensions
- Table grain
- Metric grain
- Join paths
- Multi-hop joins
- Complex joins
- Many-to-many risks
- Row multiplication risks
- Conformed dimensions
- Shared dimensions across multiple facts
- Risky relationships requiring review
- Safe reporting paths for each KPI

## Core requirement 3: Enterprise multi-fact reporting

The application must support reporting when there are multiple fact tables.

Examples:

```text
sales fact + support fact + customer dimension
orders fact + returns fact + product dimension
survey fact + operations fact + location/team dimensions
```

Rules:

- Do not blindly join fact tables directly.
- Prefer conformed dimensions for cross-fact comparison.
- Validate fact grain before combining results.
- Flag unsafe joins for review.
- Prevent row multiplication.
- Materialize safe Gold outputs only after semantic validation passes.

## Core requirement 4: Complex join validation

The application must validate joins before they are used in Gold reporting.

Validation must include:

- Primary key uniqueness check
- Foreign key coverage check
- Null key check
- Duplicate key check
- Many-to-many detection
- Row multiplication simulation
- Cardinality classification
- Join confidence score
- Join risk explanation
- Review flag when risk is high

## Core requirement 5: Governed KPI lineage

Every KPI result must be traceable.

Lineage must capture:

- KPI ID/name
- KPI formula
- Source table(s)
- Source column(s)
- Bronze table(s)
- Silver table(s)
- Gold table/view
- Applied filters
- Join path
- Grain
- Validation status
- Warnings
- Review flags
- Generated timestamp

A user or developer should be able to inspect how a KPI result was produced.

## Core requirement 6: KPI comparison engine

The application must support advanced KPI comparison for all selected KPIs.

Required capabilities:

```text
kpi_by_dimension
kpi_correlation
target_vs_actual
top_bottom_segments
variance_analysis
benchmark_gap
multi_kpi_comparison_matrix
dashboard_recommendations
```

### kpi_by_dimension

Compare every selected KPI by selected dimensions such as team, location, vendor, partner, product, customer segment, date, or category.

### kpi_correlation

Calculate KPI relationships where statistically valid and only when numeric/time-aligned data exists. Return clear messages when correlation is not valid.

### target_vs_actual

If target/goal/threshold fields exist, compare actual KPI values against targets.

### top_bottom_segments

Identify best and worst performing dimension segments for every selected KPI.

### variance_analysis

Explain which dimensions, periods, or segments contribute most to KPI movement or underperformance.

### benchmark_gap

If benchmark fields exist, compare KPI performance against benchmark values.

### dashboard_recommendations

Recommend useful dashboard blocks based on selected KPIs, available dimensions, data volume, trend availability, target fields, and benchmark fields.

## Dashboard requirements

The Gold dashboard must support:

- Multiple KPI cards
- Multiple KPI trends
- Dimension breakdowns for all selected KPIs
- Cross-KPI comparison
- KPI-by-dimension matrix
- KPI correlation view
- Target vs actual view when available
- Top/bottom segment view
- Variance analysis view
- Benchmark gap view when available
- Dashboard recommendations
- Filter-ready dashboard JSON
- Gold-only data source in the new flow
- Clear error when Gold is not ready

## Export requirements

The application must generate:

- Excel export from Gold
- PowerPoint export from Gold

Exports must be saved under:

```text
storage/exports/{dataset_id}/
```

Exports must include, when available:

- KPI summary
- KPI trends
- KPI-by-dimension
- Top/bottom segments
- Target vs actual
- Benchmark gap
- Validation summary
- Lineage summary

## LLM provider requirements

All new LLM calls must go through a LiteLLM abstraction.

Required providers:

```text
mock
openai/gpt-4o-mini
anthropic/claude-sonnet-4-20250514
```

Required environment variables:

```env
LLM_PROVIDER=mock
LLM_MODEL=mock
```

No new service should directly call OpenAI SDK or Anthropic SDK.

## Feature flag requirements

The migration must be safe.

Required flags:

```env
USE_DUCKDB_MEDALLION=false
USE_GOLD_DASHBOARD=false
USE_ENTERPRISE_SEMANTIC_MODEL=false
USE_MULTI_KPI_COMPARISON=false
```

When false, existing app behavior must remain unchanged.

When true, new uploads and dashboard routes may use the new architecture.

## Storage requirements

Default local storage:

```text
storage/uploads/
storage/duckdb/
storage/exports/
```

This structure should be compatible with future Railway volume deployment.

## Future/out-of-scope for this migration

Do not implement these now:

- BGO SSO
- SAML/OAuth2
- Workday connector
- Enterprise permissions
- Full cloud warehouse integration

## Acceptance criteria

The application is acceptable when:

1. Existing flow still works with feature flags off.
2. DuckDB Medallion flow works behind flags.
3. Bronze tables are created per CSV file and per Excel sheet.
4. Silver tables are cleaned, typed, profiled, and lineage-linked to Bronze.
5. Semantic model detects facts, dimensions, keys, grains, join paths, and conformed dimensions.
6. Enterprise multi-fact reporting avoids unsafe fact-to-fact joins.
7. Complex joins are validated for many-to-many and row multiplication risks.
8. KPI lineage is queryable for every Gold KPI result.
9. Gold dashboard reads only from Gold.
10. Multiple KPI comparison works for all selected KPIs.
11. kpi_by_dimension works.
12. kpi_correlation works where valid and fails gracefully where invalid.
13. target_vs_actual works when target fields exist.
14. top_bottom_segments works.
15. variance_analysis works.
16. benchmark_gap works when benchmark fields exist.
17. Dashboard recommendations are generated.
18. Excel and PPTX exports are generated from Gold.
19. LiteLLM mock provider works locally without external API keys.
20. Tests and smoke checks pass.
