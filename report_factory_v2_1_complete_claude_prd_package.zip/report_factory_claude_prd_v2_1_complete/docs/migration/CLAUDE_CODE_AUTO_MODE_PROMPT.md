# Claude Code Auto Mode Prompt: Report Factory Safe Migration

You are working inside the existing Report Factory application repository.

Your task is to upgrade the current application safely to support:

1. DuckDB Medallion Architecture
2. Bronze, Silver, and Gold layers
3. Gold-only dashboard/reporting pipeline
4. Stronger semantic data modeling
5. Multi-KPI comparison engine
6. LiteLLM-based model provider abstraction
7. Mock LLM provider for local testing
8. Excel and PPTX export from Gold outputs
9. Railway/volume-ready local storage structure
10. Backward-compatible migration that does not break the existing application

## Critical safety rules

Do not rewrite the whole application.
Do not delete existing working routes.
Do not remove the current SQLite metadata flow.
Do not remove the current dashboard until the new Gold dashboard is tested.
Do not directly replace root CLAUDE.md or PRD.md unless instructed later.
Do not make large destructive refactors.
Do not hardcode OpenAI or Anthropic SDK calls in new services.
Do not make dashboard read directly from raw upload/staging tables when using the new flow.

## Required migration style

Implement the new architecture behind feature flags first.

Add these environment variables:

```env
USE_DUCKDB_MEDALLION=false
USE_GOLD_DASHBOARD=false
LLM_PROVIDER=mock
LLM_MODEL=mock
DUCKDB_STORAGE_PATH=storage/duckdb
UPLOAD_STORAGE_PATH=storage/uploads
EXPORT_STORAGE_PATH=storage/exports
```

When feature flags are false, the current application must continue to work exactly as before.

When feature flags are true, new datasets should use the DuckDB Medallion pipeline.

## Required documentation setup

Create this folder if missing:

```text
docs/migration/
```

Add these files from the provided migration package:

```text
docs/migration/CLAUDE.v2.duckdb-medallion.md
docs/migration/PRD.v2.duckdb-medallion.md
docs/migration/IMPLEMENTATION_PLAN.v2.md
docs/migration/MIGRATION_CHECKLIST.md
```

Backup existing root docs if not already backed up:

```text
docs/legacy/CLAUDE.original.md
docs/legacy/PRD.original.md
```

## Implementation order

Follow this order exactly.

### Phase 0: Safety and baseline

1. Inspect current repository structure.
2. Identify backend framework, frontend framework, current routes, current DB setup, and current dashboard flow.
3. Create backup docs under `docs/legacy/`.
4. Add migration docs under `docs/migration/`.
5. Add feature flags to backend settings/config.
6. Add required dependencies but do not break existing dependencies.

Required backend dependencies:

```text
duckdb
litellm
rapidfuzz
python-pptx
openpyxl
xlsxwriter
```

### Phase 1: DuckDB foundation

Add:

```text
backend/services/duckdb/duckdb_manager.py
backend/services/duckdb/bronze_service.py
backend/services/duckdb/silver_service.py
backend/services/duckdb/gold_service.py
backend/services/duckdb/lineage_service.py
backend/services/duckdb/__init__.py
```

Required behavior:

- Create one DuckDB database per dataset/upload group.
- Default path: `storage/duckdb/{dataset_id}/report_factory.duckdb`.
- Create directories automatically.
- Provide connection manager.
- Add safe query logging.
- Add table existence checks.
- Add schema introspection utilities.

### Phase 2: Bronze layer

Bronze must ingest uploaded CSV and Excel files.

Required behavior:

- CSV: one Bronze table per file.
- Excel: one Bronze table per sheet.
- Preserve raw source columns.
- Add metadata columns:
  - `_rf_source_file`
  - `_rf_source_sheet`
  - `_rf_ingested_at`
  - `_rf_row_number`
  - `_rf_dataset_id`
- Do not apply business transformations in Bronze.
- Store ingestion logs.

### Phase 3: Silver layer

Silver must create cleaned, typed, profiled tables from Bronze.

Required behavior:

- Normalize column names.
- Infer and apply data types safely.
- Trim strings.
- Parse dates where confidence is high.
- Keep original Bronze lineage.
- Generate column profile statistics.
- Detect likely keys.
- Detect categorical/date/numeric/text columns.
- Store transformation logs.

### Phase 4: Semantic data modeling

Upgrade data modeling to use Silver tables for the new flow.

Required behavior:

- Detect fact tables.
- Detect dimension tables.
- Detect primary keys.
- Detect foreign keys.
- Detect date columns.
- Detect join relationships.
- Detect grain.
- Flag many-to-many relationships.
- Flag row multiplication risk.
- Support user overrides.
- Persist modeling result as metadata.
- Do not allow risky relationships to silently flow into Gold.

### Phase 5: KPI mapping and comparison engine

Add:

```text
backend/services/analytics/kpi_comparison_engine.py
```

Required behavior:

- Support multiple KPIs at the same time.
- Calculate KPI cards.
- Calculate KPI trends.
- Calculate KPI-by-dimension breakdowns for all selected KPIs, not only first two.
- Calculate top/bottom dimensions.
- Calculate KPI correlation where numerically valid.
- Calculate target vs actual if targets exist.
- Calculate benchmark gaps if benchmark fields exist.
- Return dashboard-ready JSON.

### Phase 6: Gold layer

Gold must materialize validated dashboard/reporting outputs.

Required Gold objects:

```text
gold_kpi_results
gold_dashboard_dataset
gold_kpi_comparison_matrix
gold_dimension_breakdowns
gold_validation_summary
gold_export_dataset
```

Required behavior:

- Gold can only read from validated Silver and semantic model outputs.
- Dashboard must not use Bronze directly.
- Gold materialization must fail if required KPI columns are missing.
- Gold materialization must fail if relationship risk is high.
- Store lineage from Gold columns back to Silver/Bronze.

### Phase 7: Gold dashboard endpoint

Add a new endpoint first. Do not replace the old one immediately.

Example:

```text
/api/dashboard/gold/{dataset_id}
```

Required behavior:

- Return dashboard data from Gold only.
- If Gold does not exist, return a clear error instructing user to materialize Gold first.
- Keep old dashboard route working.

### Phase 8: Exports

Add Gold-based exports.

Required behavior:

- Excel export from Gold.
- PPTX export from Gold.
- Export files to `storage/exports/{dataset_id}/`.
- Add endpoints to download export files.
- Do not export from raw staging tables in the new flow.

### Phase 9: LiteLLM provider abstraction

Add:

```text
backend/services/ai/litellm_client.py
backend/services/ai/mock_llm_client.py
backend/services/ai/__init__.py
```

Required behavior:

- All new LLM calls go through LiteLLM abstraction.
- Support mock provider.
- Support OpenAI provider with `openai/gpt-4o-mini`.
- Support Anthropic provider with `anthropic/claude-sonnet-4-20250514`.
- Do not hardcode model in agent files.
- Use environment variables.

### Phase 10: Tests and verification

Add or update tests for:

- CSV Bronze ingestion.
- Excel multi-sheet Bronze ingestion.
- Silver type inference.
- Fact/dimension modeling.
- Risky join detection.
- Multi-KPI comparison.
- Gold materialization.
- Gold dashboard endpoint.
- Mock LLM client.
- Existing legacy dashboard still works when feature flags are false.

## Acceptance criteria

The migration is successful only when:

1. Existing app still starts.
2. Existing dashboard still works when `USE_DUCKDB_MEDALLION=false`.
3. DuckDB files are created when `USE_DUCKDB_MEDALLION=true`.
4. Bronze tables are created for uploaded CSV and Excel sheets.
5. Silver tables are created from Bronze.
6. Semantic model is generated from Silver.
7. Gold tables are materialized after validation.
8. New Gold dashboard endpoint returns results from Gold only.
9. Multi-KPI comparison supports all selected KPIs.
10. LiteLLM abstraction exists and mock provider works locally.
11. Export endpoints generate Excel and PPTX from Gold.
12. Tests pass.
13. No destructive rewrite occurred.

## Final response required from Claude Code

When complete, provide:

1. Files changed.
2. New files added.
3. How to run old mode.
4. How to run new DuckDB mode.
5. How to test.
6. Known limitations.
7. Next recommended step.
