# Implementation Plan v2: Safe Report Factory Migration

## Goal

Upgrade the current Report Factory app without breaking it.

## Phase 0: Prepare safely

Tasks:

- Create migration docs folder.
- Backup existing CLAUDE.md and PRD.md.
- Add feature flags.
- Add dependencies.
- Confirm existing app still starts.

Done when:

- App runs in old mode.
- Feature flags exist and default to false/mock.

## Phase 1: DuckDB manager

Tasks:

- Add DuckDB manager service.
- Create dataset-specific DuckDB path.
- Add connection helper.
- Add safe table name helper.
- Add query helper.
- Add introspection helper.

Done when:

- A DuckDB file can be created for a dataset.
- Tables can be listed.

## Phase 2: Bronze ingestion

Tasks:

- Ingest CSV into Bronze.
- Ingest all Excel sheets into Bronze.
- Add metadata columns.
- Add ingestion logs.

Done when:

- CSV creates one Bronze table.
- Excel creates one Bronze table per sheet.

## Phase 3: Silver transformation

Tasks:

- Normalize column names.
- Infer types.
- Clean values safely.
- Profile columns.
- Detect keys and useful column roles.
- Preserve lineage.

Done when:

- Every Bronze table can create a Silver table.
- Profiles are available.

## Phase 4: Semantic modeling

Tasks:

- Use Silver tables.
- Detect facts and dimensions.
- Detect primary and foreign keys.
- Detect relationships.
- Detect grain.
- Flag many-to-many risks.
- Flag row multiplication risks.

Done when:

- Model output explains tables, keys, joins, confidence, and risks.

## Phase 5: Multi-KPI comparison engine

Tasks:

- Support all selected KPIs.
- Generate KPI cards.
- Generate trends.
- Generate all-KPI dimension breakdowns.
- Generate top/bottom performers.
- Generate correlation where valid.
- Generate target/benchmark comparisons where available.

Done when:

- 3 or more KPIs can be compared across dimensions.

## Phase 6: Gold materialization

Tasks:

- Create Gold tables.
- Validate KPI inputs.
- Validate relationship risk.
- Store lineage.
- Store validation summary.

Done when:

- Gold objects exist and dashboard can read them.

## Phase 7: Gold dashboard endpoint

Tasks:

- Add Gold dashboard endpoint.
- Return dashboard JSON from Gold only.
- Keep old dashboard route working.

Done when:

- Old dashboard works in old mode.
- Gold dashboard works in new mode.

## Phase 8: Gold exports

Tasks:

- Add Excel export.
- Add PowerPoint export.
- Save files to storage/exports.
- Add download endpoints.

Done when:

- Excel and PPTX files are generated from Gold.

## Phase 9: LiteLLM provider

Tasks:

- Add mock provider.
- Add LiteLLM client.
- Support OpenAI model config.
- Support Anthropic model config.
- Remove hardcoded model use from new flows.

Done when:

- Local mock mode works without API key.
- Real model mode can be enabled via env.

## Phase 10: Tests and final verification

Tasks:

- Add unit tests.
- Add integration tests where practical.
- Test old mode.
- Test new mode.
- Document commands.

Done when:

- Tests pass.
- App starts.
- Existing flow still works.
- New flow works behind flags.
