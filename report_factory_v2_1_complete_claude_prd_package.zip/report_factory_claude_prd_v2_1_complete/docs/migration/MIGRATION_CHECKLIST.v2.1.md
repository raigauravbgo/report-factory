# Migration Checklist v2.1

Claude Code must use this checklist before calling the migration complete.

## Safety

- [ ] Current app starts in old mode.
- [ ] Current dashboard still works when USE_GOLD_DASHBOARD=false.
- [ ] Current upload flow still works when USE_DUCKDB_MEDALLION=false.
- [ ] Existing root CLAUDE.md and PRD.md were backed up before any overwrite.
- [ ] New docs were added under docs/migration/.

## DuckDB Medallion Architecture

- [ ] DuckDB dependency added.
- [ ] Dataset-specific DuckDB file is created.
- [ ] Bronze layer exists.
- [ ] Silver layer exists.
- [ ] Gold layer exists.
- [ ] CSV creates Bronze table.
- [ ] Excel creates one Bronze table per sheet.
- [ ] Silver tables include cleaned names, inferred types, profiles, and lineage.
- [ ] Gold objects are created only after validation.

## Semantic data modeling

- [ ] semantic_model_service.py exists.
- [ ] Fact tables are detected.
- [ ] Dimension tables are detected.
- [ ] Enterprise multi-fact reporting is supported.
- [ ] Conformed dimensions are detected.
- [ ] Table grain is detected.
- [ ] Primary keys are detected.
- [ ] Foreign keys are detected.
- [ ] Composite key possibilities are handled.
- [ ] Complex joins are classified.
- [ ] Many-to-many joins are flagged.
- [ ] Row multiplication risk is checked.
- [ ] Validated semantic model contract is persisted.
- [ ] Blocking semantic model issues prevent Gold materialization.

## Governed KPI lineage

- [ ] KPI lineage registry exists.
- [ ] Each KPI stores source tables.
- [ ] Each KPI stores source columns.
- [ ] Each KPI stores formula.
- [ ] Each KPI stores join path.
- [ ] Each KPI stores grain.
- [ ] Each KPI stores validation status.
- [ ] KPI lineage API exists.
- [ ] Dashboard can expose KPI lineage.

## KPI comparison engine

- [ ] kpi_comparison_engine.py exists.
- [ ] kpi_by_dimension.py exists.
- [ ] kpi_correlation.py exists.
- [ ] target_vs_actual.py exists.
- [ ] top_bottom_segments.py exists.
- [ ] variance_analysis.py exists.
- [ ] benchmark_gap.py exists.
- [ ] Cross-KPI comparison works for all selected KPIs, not only first two.
- [ ] kpi_by_dimension supports all selected KPIs.
- [ ] kpi_correlation avoids fake correlation when data is insufficient.
- [ ] target_vs_actual works when target values/columns exist.
- [ ] top_bottom_segments identifies best/worst performers.
- [ ] variance_analysis identifies high-gap dimensions.
- [ ] benchmark_gap works when benchmark values/columns exist.

## Gold-layer reporting

- [ ] gold_kpi_results exists.
- [ ] gold_dashboard_dataset exists.
- [ ] gold_kpi_by_dimension exists.
- [ ] gold_kpi_correlation exists.
- [ ] gold_target_vs_actual exists.
- [ ] gold_top_bottom_segments exists.
- [ ] gold_variance_analysis exists.
- [ ] gold_benchmark_gap exists.
- [ ] gold_dashboard_recommendations exists.
- [ ] gold_validation_summary exists.
- [ ] gold_kpi_lineage exists.
- [ ] gold_export_dataset exists.
- [ ] Dashboard reads Gold only when USE_GOLD_DASHBOARD=true.
- [ ] Export reads Gold only in new mode.

## Dashboard recommendation

- [ ] dashboard_recommendation_engine.py exists.
- [ ] Dashboard sections are recommended based on data availability.
- [ ] Missing/blocked sections include reasons.
- [ ] Warnings from validation appear in dashboard response.
- [ ] Recommended sections are included in Gold dashboard API response.

## LiteLLM

- [ ] litellm dependency added.
- [ ] mock provider exists.
- [ ] OpenAI gpt-4o-mini config exists.
- [ ] Anthropic Claude Sonnet config exists.
- [ ] New LLM calls do not directly call OpenAI SDK or Anthropic SDK.

## Tests / smoke checks

- [ ] Old mode smoke test passes.
- [ ] New DuckDB mode smoke test passes.
- [ ] Semantic model smoke test passes.
- [ ] Gold materialization smoke test passes.
- [ ] Multi-KPI comparison smoke test passes with at least 3 KPIs.
- [ ] KPI lineage API smoke test passes.
- [ ] Dashboard recommendation smoke test passes.
- [ ] Export smoke test passes.
