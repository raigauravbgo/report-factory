# Migration Checklist

## Before coding

- [ ] Working branch created
- [ ] Current app starts
- [ ] Current CLAUDE.md backed up
- [ ] Current PRD.md backed up
- [ ] Migration docs added

## Feature flags

- [ ] USE_DUCKDB_MEDALLION added
- [ ] USE_GOLD_DASHBOARD added
- [ ] LLM_PROVIDER added
- [ ] LLM_MODEL added
- [ ] Storage paths added

## Dependencies

- [ ] duckdb added
- [ ] litellm added
- [ ] rapidfuzz added
- [ ] python-pptx added
- [ ] xlsxwriter added

## DuckDB

- [ ] DuckDB manager added
- [ ] Dataset-specific DB file created
- [ ] Safe table names implemented
- [ ] Schema introspection implemented

## Bronze

- [ ] CSV ingestion works
- [ ] Excel multi-sheet ingestion works
- [ ] Metadata columns added
- [ ] Ingestion logs added

## Silver

- [ ] Column normalization works
- [ ] Type inference works
- [ ] Profiling works
- [ ] Key detection works
- [ ] Lineage preserved

## Semantic modeling

- [ ] Fact detection works
- [ ] Dimension detection works
- [ ] Relationship detection works
- [ ] Grain detection works
- [ ] Many-to-many risk flagged
- [ ] Row multiplication risk flagged

## KPI comparison

- [ ] Multiple KPI cards work
- [ ] Multiple KPI trends work
- [ ] Dimension breakdown supports all selected KPIs
- [ ] Top/bottom performers work
- [ ] Correlation works where valid
- [ ] Target/benchmark comparison works where available

## Gold

- [ ] gold_kpi_results created
- [ ] gold_dashboard_dataset created
- [ ] gold_kpi_comparison_matrix created
- [ ] gold_dimension_breakdowns created
- [ ] gold_validation_summary created
- [ ] gold_export_dataset created

## Dashboard

- [ ] New Gold dashboard endpoint added
- [ ] Old dashboard still works
- [ ] Gold dashboard reads only from Gold
- [ ] Clear error when Gold is missing

## Exports

- [ ] Excel export works from Gold
- [ ] PPTX export works from Gold
- [ ] Files saved under storage/exports

## LLM

- [ ] Mock provider works
- [ ] LiteLLM client added
- [ ] OpenAI config supported
- [ ] Anthropic config supported
- [ ] New flows avoid direct SDK calls

## Final verification

- [ ] Old mode works
- [ ] New mode works
- [ ] Tests pass
- [ ] Changed files documented
- [ ] Known limitations documented
