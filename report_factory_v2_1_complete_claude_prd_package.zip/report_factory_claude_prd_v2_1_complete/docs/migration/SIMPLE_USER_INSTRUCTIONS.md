# Simple Instructions for Non-Technical Use

## What you should do

1. Open your Report Factory project in Claude Code.
2. Make sure your project is saved in GitHub or at least copied somewhere safe.
3. Ask Claude Code to create a new branch:

```bash
git checkout -b feature/duckdb-medallion-safe-migration
```

4. Upload or paste these files to Claude Code:

```text
CLAUDE_CODE_AUTO_MODE_PROMPT.md
CLAUDE.v2.duckdb-medallion.md
PRD.v2.duckdb-medallion.md
IMPLEMENTATION_PLAN.v2.md
MIGRATION_CHECKLIST.md
```

5. Tell Claude Code:

```text
Follow CLAUDE_CODE_AUTO_MODE_PROMPT.md exactly. Work in safe migration mode. Do not delete existing working features. Add the new DuckDB Medallion, Gold Dashboard, multi-KPI comparison, and LiteLLM support behind feature flags first.
```

## What not to do

Do not say:

```text
Rewrite my application completely.
```

Do not say:

```text
Replace everything with the new architecture.
```

Do not say:

```text
Overwrite all files.
```

## Safer wording

Say this instead:

```text
Upgrade my existing application safely. Preserve the current working app. Add the new architecture behind feature flags. Only switch defaults after tests pass.
```

## After Claude Code finishes

Ask Claude Code:

```text
Please show me:
1. What files you changed
2. How I run the old mode
3. How I run the new DuckDB mode
4. How I test upload, dashboard, and export
5. Any remaining issues
```
