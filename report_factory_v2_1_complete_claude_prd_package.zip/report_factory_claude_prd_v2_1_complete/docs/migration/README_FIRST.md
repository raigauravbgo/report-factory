# README FIRST - Report Factory Claude Code Package v2.1

Use this package with Claude Code to safely upgrade your current Report Factory app.

## What changed in v2.1

This version explicitly adds the items that were missing or not clearly visible in the previous plan:

- Data modeling
- Enterprise multi-fact reporting
- Cross-KPI comparison
- Validated semantic model
- Gold-layer reporting
- Complex joins
- Governed KPI lineage
- KPI comparison engine
- kpi_by_dimension
- kpi_correlation
- target_vs_actual
- top_bottom_segments
- variance_analysis
- benchmark_gap
- Dashboard recommendation
- DuckDB Medallion Architecture
- Gold layer
- Semantic data modeling
- Multi-KPI comparison backend

## Which file to give Claude Code first

Give Claude Code this file first:

```text
CLAUDE_CODE_AUTO_MODE_PROMPT.v2.1.md
```

Then give it the other files as supporting reference.

## Simple instruction to paste into Claude Code

```text
Please upgrade my existing Report Factory app safely using this v2.1 migration package.

Follow CLAUDE_CODE_AUTO_MODE_PROMPT.v2.1.md first.
Then follow PRD.v2.duckdb-medallion.md, IMPLEMENTATION_PLAN.v2.1.md, ENTERPRISE_ANALYTICS_ADDENDUM.v2.1.md, and MIGRATION_CHECKLIST.v2.1.md.

I am not technical, so do the work in auto mode.
Do not rewrite everything.
Do not delete existing working features.
Keep old mode working behind feature flags.
Implement DuckDB Medallion Architecture, Gold layer, semantic data modeling, enterprise multi-fact reporting, governed KPI lineage, KPI comparison engine, dashboard recommendations, and Gold dashboard safely.
```
