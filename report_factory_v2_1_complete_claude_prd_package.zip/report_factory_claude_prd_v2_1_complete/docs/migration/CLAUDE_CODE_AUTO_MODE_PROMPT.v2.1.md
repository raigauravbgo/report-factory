# Claude Code Auto Mode Prompt v2.1

You are upgrading an existing Report Factory application. The user is not technical. Work safely and implement the migration without requiring the user to make architecture decisions.

## Non-negotiable safety rules

1. Do not rewrite the whole application.
2. Do not delete existing working routes, pages, or services.
3. Do not break the current dashboard.
4. Keep existing root CLAUDE.md and PRD.md unchanged at first.
5. Backup current docs to docs/legacy/.
6. Add new docs to docs/migration/.
7. Use feature flags so old mode remains working.
8. Default local AI mode to mock so the app can run without paid API calls.
9. Implement in small commits/steps.
10. Run tests or smoke checks after each major phase.

## Required feature flags

```env
USE_DUCKDB_MEDALLION=false
USE_GOLD_DASHBOARD=false
USE_ENTERPRISE_SEMANTIC_MODEL=false
USE_MULTI_KPI_ENGINE=false
LLM_PROVIDER=mock
LLM_MODEL=mock
```

## Required implementation scope

You must implement all items from:

```text
PRD.v2.duckdb-medallion.md
CLAUDE.v2.duckdb-medallion.md
IMPLEMENTATION_PLAN.v2.md
ENTERPRISE_ANALYTICS_ADDENDUM.v2.1.md
MIGRATION_CHECKLIST.v2.1.md
```

The following items are mandatory, not optional:

```text
Data modeling
Enterprise multi-fact reporting
Cross-KPI comparison
Validated semantic model
Gold-layer reporting
Complex joins
Governed KPI lineage
KPI comparison engine
kpi_by_dimension
kpi_correlation
target_vs_actual
top_bottom_segments
variance_analysis
benchmark_gap
Dashboard recommendation
DuckDB Medallion Architecture
Gold layer
Semantic data modeling
Multi-KPI comparison backend
```

## Required backend modules

Create/update:

```text
backend/services/duckdb/duckdb_manager.py
backend/services/duckdb/bronze_service.py
backend/services/duckdb/silver_service.py
backend/services/duckdb/gold_service.py
backend/services/duckdb/lineage_service.py

backend/services/semantic/semantic_model_service.py
backend/services/semantic/fact_dimension_classifier.py
backend/services/semantic/relationship_detector.py
backend/services/semantic/grain_detector.py
backend/services/semantic/join_validator.py
backend/services/semantic/lineage_registry.py
backend/services/semantic/semantic_contracts.py

backend/services/analytics/kpi_comparison_engine.py
backend/services/analytics/kpi_by_dimension.py
backend/services/analytics/kpi_correlation.py
backend/services/analytics/target_vs_actual.py
backend/services/analytics/top_bottom_segments.py
backend/services/analytics/variance_analysis.py
backend/services/analytics/benchmark_gap.py
backend/services/analytics/dashboard_recommendation_engine.py

backend/services/ai/litellm_client.py
```

## Required Gold tables/views

Create Gold outputs in DuckDB:

```text
gold_kpi_results
gold_dashboard_dataset
gold_kpi_by_dimension
gold_kpi_correlation
gold_target_vs_actual
gold_top_bottom_segments
gold_variance_analysis
gold_benchmark_gap
gold_dashboard_recommendations
gold_validation_summary
gold_kpi_lineage
gold_export_dataset
```

## Required endpoints

Add without deleting old endpoints:

```text
GET  /api/semantic-model/{dataset_id}
POST /api/semantic-model/{dataset_id}/validate
GET  /api/dashboard/gold/{dataset_id}
GET  /api/analytics/kpi-comparison/{dataset_id}
GET  /api/analytics/kpi-by-dimension/{dataset_id}
GET  /api/analytics/kpi-correlation/{dataset_id}
GET  /api/analytics/target-vs-actual/{dataset_id}
GET  /api/analytics/top-bottom-segments/{dataset_id}
GET  /api/analytics/variance-analysis/{dataset_id}
GET  /api/analytics/benchmark-gap/{dataset_id}
GET  /api/dashboard/recommendations/{dataset_id}
GET  /api/lineage/kpi/{dataset_id}/{kpi_id}
```

## Required frontend dashboard additions

Add these sections behind feature flags:

```text
KPI cards
KPI trend comparison
KPI by dimension
KPI correlation matrix
Target vs actual
Top/bottom segments
Variance analysis
Benchmark gap
Dashboard recommendations
Validation warnings
KPI lineage drawer/modal
```

## Completion rule

Do not say the work is complete until:

1. Existing app still runs in old mode.
2. New DuckDB Medallion flow runs behind flags.
3. Gold dashboard endpoint works.
4. Multi-KPI comparison works for 3 or more KPIs.
5. Semantic model supports multi-fact reporting and complex join validation.
6. KPI lineage is exposed through API.
7. Dashboard recommendations are returned through API.
8. Tests or smoke checks cover all major modules.
9. Migration checklist is fully passed.
