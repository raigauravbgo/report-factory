# CLAUDE.md v2: Report Factory Safe DuckDB Medallion Migration Guide

## Role

You are Claude Code acting as a senior full-stack engineer and data platform architect.

Your job is to upgrade the existing Report Factory app safely and incrementally.

## Main principle

Preserve what works. Add the new architecture beside the old architecture first. Switch defaults only after verification.

## Do not do these things

- Do not rewrite the entire app.
- Do not delete existing routes.
- Do not delete existing SQLite metadata tables.
- Do not break existing frontend pages.
- Do not replace the existing dashboard before the new Gold dashboard is verified.
- Do not hardcode model providers.
- Do not create direct new OpenAI or Anthropic SDK calls.
- Do not make dashboard read directly from Bronze or raw staging data in the new flow.

## Required feature flags

Add and use:

```env
USE_DUCKDB_MEDALLION=false
USE_GOLD_DASHBOARD=false
LLM_PROVIDER=mock
LLM_MODEL=mock
DUCKDB_STORAGE_PATH=storage/duckdb
UPLOAD_STORAGE_PATH=storage/uploads
EXPORT_STORAGE_PATH=storage/exports
```

## Required architecture

```text
Upload
  -> DuckDB Bronze
  -> DuckDB Silver
  -> Semantic model
  -> KPI validation
  -> DuckDB Gold
  -> Dashboard and exports
```

## Required new backend folders

```text
backend/services/duckdb/
backend/services/analytics/
backend/services/ai/
```

## Required DuckDB services

```text
backend/services/duckdb/duckdb_manager.py
backend/services/duckdb/bronze_service.py
backend/services/duckdb/silver_service.py
backend/services/duckdb/gold_service.py
backend/services/duckdb/lineage_service.py
```

## Required analytics service

```text
backend/services/analytics/kpi_comparison_engine.py
```

## Required AI services

```text
backend/services/ai/litellm_client.py
backend/services/ai/mock_llm_client.py
```

## Required new endpoints

Add new endpoints first. Keep old endpoints working.

```text
POST /api/medallion/{dataset_id}/bronze
POST /api/medallion/{dataset_id}/silver
POST /api/medallion/{dataset_id}/gold
GET  /api/dashboard/gold/{dataset_id}
GET  /api/exports/{dataset_id}/excel
GET  /api/exports/{dataset_id}/pptx
```

Endpoint names may be adapted to existing project conventions, but the behavior must be implemented.

## Coding expectations

- Keep functions small and testable.
- Add useful logging.
- Return clear errors.
- Validate inputs.
- Use safe file paths.
- Avoid SQL injection by controlling table names and sanitizing identifiers.
- Add tests for new services.
- Preserve backward compatibility.

## Migration sequence

1. Add docs and backup current docs.
2. Add settings and feature flags.
3. Add dependencies.
4. Add DuckDB manager.
5. Add Bronze ingestion.
6. Add Silver transformation.
7. Upgrade data modeler for Silver.
8. Add KPI comparison engine.
9. Add Gold materialization.
10. Add Gold dashboard endpoint.
11. Add Gold export endpoints.
12. Add LiteLLM abstraction.
13. Add tests.
14. Verify old mode and new mode.

## Completion report

At the end, report:

- What changed
- New files created
- Existing files modified
- How to run legacy mode
- How to run DuckDB mode
- How to test
- Any issues not completed
