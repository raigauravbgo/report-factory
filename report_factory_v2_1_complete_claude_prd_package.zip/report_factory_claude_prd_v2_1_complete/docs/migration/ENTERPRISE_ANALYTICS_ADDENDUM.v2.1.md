# Enterprise Analytics Addendum v2.1

This addendum is mandatory. Claude Code must implement these requirements explicitly, not treat them as optional or future work.

## Purpose

Upgrade Report Factory so it can support enterprise-grade multi-file reporting, multi-fact data modeling, cross-KPI analysis, governed KPI lineage, Gold-layer reporting, and dashboard recommendations.

## Required major modules

Claude Code must add or update these backend modules:

```text
backend/services/semantic/
  semantic_model_service.py
  fact_dimension_classifier.py
  relationship_detector.py
  grain_detector.py
  join_validator.py
  lineage_registry.py
  semantic_contracts.py

backend/services/analytics/
  kpi_comparison_engine.py
  kpi_by_dimension.py
  kpi_correlation.py
  target_vs_actual.py
  top_bottom_segments.py
  variance_analysis.py
  benchmark_gap.py
  dashboard_recommendation_engine.py

backend/services/duckdb/
  duckdb_manager.py
  bronze_service.py
  silver_service.py
  gold_service.py
  lineage_service.py
```

Do not remove current working services until the new flow is verified behind feature flags.

---

# 1. Data modeling requirements

The new data modeling layer must support the following explicitly:

## 1.1 Enterprise multi-fact reporting

The app must support more than one fact table in a dataset.

Examples:

```text
sales_fact
returns_fact
inventory_fact
support_ticket_fact
customer_feedback_fact
```

Required behavior:

- Detect multiple fact tables.
- Detect shared dimensions across facts.
- Detect conformed dimensions such as date, customer, product, vendor, location, team, partner, region, department, category.
- Support dashboard recipes using one fact or multiple facts.
- Prevent unsafe joins between fact tables unless a valid shared grain or bridge path exists.
- Flag direct fact-to-fact joins as high risk unless proven safe.

Acceptance criteria:

```text
Given 3 uploaded files with 2 facts and 1 shared dimension,
the system identifies both fact tables,
identifies the shared dimension,
proposes safe join paths,
and flags risky fact-to-fact joins.
```

## 1.2 Complex joins

The semantic model must support:

- one-to-one joins
- one-to-many joins
- many-to-one joins
- many-to-many detection
- bridge table detection
- composite key joins
- date joins
- fuzzy relationship suggestions
- user-approved relationship overrides

Many-to-many joins must not silently proceed into Gold.

Acceptance criteria:

```text
If a relationship creates row multiplication risk,
Gold materialization must either block or require human review.
```

## 1.3 Validated semantic model

The model must produce a persisted semantic contract.

Required semantic contract fields:

```json
{
  "dataset_id": "string",
  "tables": [],
  "facts": [],
  "dimensions": [],
  "relationships": [],
  "grains": [],
  "join_paths": [],
  "conformed_dimensions": [],
  "warnings": [],
  "blocking_issues": [],
  "confidence_score": 0.0
}
```

The semantic model must be validated before Gold materialization.

Blocking issues:

- no fact table found
- no valid KPI source columns found
- unsafe many-to-many join
- missing date/time grain for time trend when trend is requested
- KPI formula references missing fields
- ambiguous relationship selected without approval

---

# 2. Governed KPI lineage

Every KPI result must have lineage.

Required lineage fields:

```json
{
  "kpi_id": "string",
  "kpi_name": "string",
  "formula": "string",
  "source_tables": [],
  "source_columns": [],
  "silver_tables": [],
  "gold_tables": [],
  "filters_applied": [],
  "join_path": [],
  "grain": "string",
  "validation_status": "passed|warning|blocked",
  "confidence_score": 0.0
}
```

Lineage must be saved in DuckDB metadata or SQLite metadata and exposed through API.

Required endpoint:

```text
GET /api/lineage/kpi/{dataset_id}/{kpi_id}
```

Acceptance criteria:

```text
For every KPI displayed in dashboard,
user can inspect where it came from,
which columns were used,
which joins were used,
and whether validation passed.
```

---

# 3. KPI comparison engine

Claude Code must implement a real KPI comparison backend, not only KPI cards.

Required service:

```text
backend/services/analytics/kpi_comparison_engine.py
```

It must orchestrate the modules below.

## 3.1 kpi_by_dimension

Required output:

```json
{
  "dimension": "team",
  "rows": [
    {
      "dimension_value": "Team A",
      "kpis": {
        "csat": 4.2,
        "nps": 55,
        "resolution_rate": 0.91
      }
    }
  ]
}
```

Must support all selected KPIs, not only the first two.

## 3.2 kpi_correlation

Calculate correlation only when valid numeric KPI series are available.

Required output:

```json
{
  "pairs": [
    {
      "kpi_a": "csat",
      "kpi_b": "aht",
      "correlation": -0.42,
      "method": "pearson",
      "interpretation": "Moderate negative relationship",
      "sample_size": 30
    }
  ]
}
```

If correlation is not statistically meaningful, return a warning instead of fake insight.

## 3.3 target_vs_actual

Detect target columns or user-provided target values.

Required output:

```json
{
  "kpi_id": "csat",
  "actual": 4.2,
  "target": 4.5,
  "gap": -0.3,
  "gap_percent": -6.67,
  "status": "below_target"
}
```

## 3.4 top_bottom_segments

For every dimension and KPI, identify best and worst performers.

Required output:

```json
{
  "kpi_id": "nps",
  "dimension": "location",
  "top": [],
  "bottom": []
}
```

## 3.5 variance_analysis

Explain which dimensions contribute most to KPI variation.

Required output:

```json
{
  "kpi_id": "csat",
  "dimension": "team",
  "variance_score": 0.72,
  "largest_gap": 1.4,
  "largest_gap_between": ["Team A", "Team D"],
  "recommendation": "Review Team D drivers because it is the largest negative outlier."
}
```

## 3.6 benchmark_gap

When benchmark columns or benchmark config exist, compare actual KPI values against benchmark.

Required output:

```json
{
  "kpi_id": "resolution_rate",
  "actual": 0.88,
  "benchmark": 0.92,
  "gap": -0.04,
  "status": "below_benchmark"
}
```

---

# 4. Gold-layer reporting

Gold is mandatory for new mode.

Dashboard, exports, and narrative must read from Gold only when:

```env
USE_DUCKDB_MEDALLION=true
USE_GOLD_DASHBOARD=true
```

Required Gold objects:

```text
gold_kpi_results
gold_dashboard_dataset
gold_kpi_by_dimension
gold_kpi_correlation
gold_target_vs_actual
gold_top_bottom_segments
gold_variance_analysis
gold_benchmark_gap
gold_dashboard_recommendations
gold_validation_summary
gold_kpi_lineage
gold_export_dataset
```

Gold must include validation status.

Required statuses:

```text
passed
warning
blocked
needs_review
```

Dashboard must not hide blocked issues.

---

# 5. Dashboard recommendation engine

Required service:

```text
backend/services/analytics/dashboard_recommendation_engine.py
```

The recommendation engine must recommend dashboard layout and charts based on the semantic model and KPI outputs.

Required recommendations:

- KPI cards for selected KPIs
- trend charts when date grain exists
- dimension comparison charts when dimensions exist
- top/bottom segment tables
- target vs actual visual when targets exist
- benchmark gap visual when benchmarks exist
- correlation matrix when valid KPI pairs exist
- warning panel when semantic model or Gold validation has warnings
- lineage panel for KPI explainability

Required output:

```json
{
  "recommended_sections": [
    {
      "section_type": "kpi_cards",
      "priority": 1,
      "reason": "Selected KPIs have valid Gold results."
    },
    {
      "section_type": "kpi_by_dimension",
      "priority": 2,
      "reason": "Team and Location are valid dimensions."
    }
  ],
  "warnings": [],
  "blocked_sections": []
}
```

Acceptance criteria:

```text
Dashboard response includes recommended_sections and explains why each section appears or is hidden.
```

---

# 6. API requirements

Add these endpoints without deleting old endpoints:

```text
GET  /api/semantic-model/{dataset_id}
POST /api/semantic-model/{dataset_id}/validate
GET  /api/dashboard/gold/{dataset_id}
GET  /api/analytics/kpi-comparison/{dataset_id}
GET  /api/analytics/kpi-by-dimension/{dataset_id}
GET  /api/analytics/kpi-correlation/{dataset_id}
GET  /api/analytics/target-vs-actual/{dataset_id}
GET  /api/analytics/top-bottom-segments/{dataset_id}
GET  /api/analytics/variance-analysis/{dataset_id}
GET  /api/analytics/benchmark-gap/{dataset_id}
GET  /api/dashboard/recommendations/{dataset_id}
GET  /api/lineage/kpi/{dataset_id}/{kpi_id}
```

---

# 7. Frontend requirements

Add frontend support without breaking current dashboard.

Required dashboard sections:

- KPI cards
- KPI trend comparison
- KPI by dimension table/chart
- KPI correlation matrix
- target vs actual cards
- top/bottom segment cards
- variance analysis panel
- benchmark gap panel
- dashboard recommendations panel
- validation warnings panel
- KPI lineage drawer/modal

Feature flag behavior:

```text
If USE_GOLD_DASHBOARD=false, current dashboard stays unchanged.
If USE_GOLD_DASHBOARD=true, dashboard uses Gold API.
```

---

# 8. Claude Code implementation rules

Claude Code must not mark the migration complete unless all these exact terms exist in code, docs, or tests:

```text
enterprise multi-fact reporting
cross-KPI comparison
validated semantic model
Gold-layer reporting
complex joins
governed KPI lineage
kpi_by_dimension
kpi_correlation
target_vs_actual
top_bottom_segments
variance_analysis
benchmark_gap
dashboard recommendation
DuckDB Medallion Architecture
Gold layer
Semantic data modeling
Multi-KPI comparison backend
```

Add tests or smoke checks for each major module.

