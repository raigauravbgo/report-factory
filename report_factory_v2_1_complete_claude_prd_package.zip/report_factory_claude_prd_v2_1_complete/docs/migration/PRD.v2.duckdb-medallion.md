# Report Factory PRD v2: DuckDB Medallion + Gold Reporting Migration

## Product goal

Upgrade Report Factory from a prototype reporting application into a safer, more reliable, multi-file, multi-KPI reporting platform.

The upgraded application must support uploaded business datasets, semantic modeling, KPI selection, validated Gold reporting outputs, dashboard generation, and export generation.

## Non-technical summary

The application should let a user upload CSV/Excel files, automatically understand the data, suggest useful KPIs, build a reliable data model, calculate multiple KPIs, compare them across dimensions, and generate dashboard/export outputs without requiring manual SQL work.

## Current application status

The current application already has:

- Upload flow
- Profiling flow
- Schema mapping flow
- Data modeling flow
- KPI selection flow
- Dashboard flow
- Some AI/agent support
- SQLite-based metadata and staging behavior

The current application does not yet have:

- DuckDB Medallion Architecture
- Bronze/Silver/Gold layers
- Gold-only dashboard
- Strong multi-KPI comparison engine
- Full semantic data modeling governance
- LiteLLM provider abstraction
- Gold-based Excel/PPTX export

## Target architecture

```text
Upload files
  -> DuckDB session
  -> Bronze raw tables
  -> Silver cleaned/profiled tables
  -> Semantic data model
  -> KPI mapping and validation
  -> Gold reporting tables
  -> Dashboard / Excel / PPTX / Narrative
```

## Core requirement: DuckDB Medallion Architecture

The application must use DuckDB as the analytical engine for uploaded datasets.

SQLite may remain for application metadata, but analytical tables must move to DuckDB in the new flow.

### DuckDB session

Each dataset/upload group must have its own DuckDB database:

```text
storage/duckdb/{dataset_id}/report_factory.duckdb
```

### Bronze layer

Bronze stores raw uploaded data.

Rules:

- One Bronze table per CSV file.
- One Bronze table per Excel sheet.
- Do not apply business transformations.
- Preserve raw columns.
- Add ingestion metadata.

### Silver layer

Silver stores cleaned and typed data.

Rules:

- Normalize column names.
- Infer data types.
- Profile columns.
- Detect likely keys.
- Detect categorical/date/numeric/text columns.
- Preserve lineage to Bronze.

### Gold layer

Gold stores validated reporting outputs.

Rules:

- Dashboard must read from Gold only in the new flow.
- Exports must read from Gold only in the new flow.
- Gold must fail clearly when validation fails.
- Gold must preserve lineage.

Required Gold objects:

```text
gold_kpi_results
gold_dashboard_dataset
gold_kpi_comparison_matrix
gold_dimension_breakdowns
gold_validation_summary
gold_export_dataset
```

## Data modeling requirements

The application must detect and validate:

- Fact tables
- Dimension tables
- Primary keys
- Foreign keys
- Date dimensions
- Table grain
- Join paths
- Many-to-many risks
- Row multiplication risks
- Conformed dimensions
- Risky relationships requiring review

## KPI requirements

The application must support:

- Multiple selected KPIs
- KPI cards
- KPI trends
- Period-over-period change
- KPI by dimension
- KPI comparison matrix
- Top/bottom dimension performers
- Target vs actual when target fields exist
- Benchmark gap when benchmark fields exist
- KPI correlation where valid
- KPI validation before Gold materialization

## Dashboard requirements

The dashboard must support:

- Multiple KPI cards
- Multiple KPI trends
- Dimension breakdowns for all selected KPIs
- Filter-ready dashboard JSON
- Gold-only data source in the new flow
- Clear errors if Gold is not ready

## Export requirements

The application must generate:

- Excel export from Gold
- PowerPoint export from Gold

Exports must be saved under:

```text
storage/exports/{dataset_id}/
```

## LLM provider requirements

All new LLM calls must go through a LiteLLM abstraction.

Required providers:

```text
mock
openai/gpt-4o-mini
anthropic/claude-sonnet-4-20250514
```

Required environment variables:

```env
LLM_PROVIDER=mock
LLM_MODEL=mock
```

No new service should directly call OpenAI SDK or Anthropic SDK.

## Feature flag requirements

The migration must be safe.

Required flags:

```env
USE_DUCKDB_MEDALLION=false
USE_GOLD_DASHBOARD=false
```

When false, existing app behavior must remain unchanged.

When true, new uploads and dashboard routes may use the new architecture.

## Storage requirements

Default local storage:

```text
storage/uploads/
storage/duckdb/
storage/exports/
```

This structure should be compatible with future Railway volume deployment.

## Future/out-of-scope for this migration

Do not implement these now:

- BGO SSO
- SAML/OAuth2
- Workday connector
- Enterprise permissions
- Full cloud warehouse integration

## Acceptance criteria

The application is acceptable when:

1. Existing flow still works.
2. DuckDB Medallion flow works behind flags.
3. Bronze/Silver/Gold tables are created correctly.
4. Gold dashboard reads only from Gold.
5. Multiple KPI comparison works for all selected KPIs.
6. LiteLLM mock provider works locally.
7. Excel/PPTX exports are generated from Gold.
8. Tests pass.
