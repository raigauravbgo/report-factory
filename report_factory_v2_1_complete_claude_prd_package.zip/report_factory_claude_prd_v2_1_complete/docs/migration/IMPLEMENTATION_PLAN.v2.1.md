# Implementation Plan v2.1: Safe Enterprise Analytics Migration

This plan is the simple step-by-step order Claude Code should follow. Do not skip phases.

## Phase 0: Backup and safety flags

- Backup current CLAUDE.md and PRD.md into docs/legacy/.
- Add docs/migration/ and copy the v2/v2.1 docs there.
- Add feature flags:
  - USE_DUCKDB_MEDALLION=false
  - USE_GOLD_DASHBOARD=false
  - USE_ENTERPRISE_SEMANTIC_MODEL=false
  - USE_MULTI_KPI_ENGINE=false
  - LLM_PROVIDER=mock
  - LLM_MODEL=mock
- Confirm old app still runs.

## Phase 1: DuckDB Medallion Architecture

Implement:

- DuckDB manager
- Bronze service
- Silver service
- Gold service
- Lineage service

Deliverables:

- storage/duckdb/{dataset_id}/report_factory.duckdb
- Bronze raw tables
- Silver cleaned/profiled tables
- Gold reporting tables

## Phase 2: Semantic data modeling

Implement enterprise semantic model services:

- fact/dimension classification
- enterprise multi-fact reporting support
- conformed dimension detection
- grain detection
- complex join classification
- many-to-many risk detection
- row multiplication protection
- validated semantic model contract

Deliverables:

- persisted semantic model JSON
- semantic model validation endpoint
- blocking issues before Gold materialization

## Phase 3: Governed KPI lineage

Implement KPI lineage registry.

Each KPI must record:

- source tables
- source columns
- formula
- join path
- grain
- Silver tables
- Gold tables
- validation status
- confidence score

Deliverable:

- GET /api/lineage/kpi/{dataset_id}/{kpi_id}

## Phase 4: KPI comparison engine

Implement:

- kpi_comparison_engine
- kpi_by_dimension
- kpi_correlation
- target_vs_actual
- top_bottom_segments
- variance_analysis
- benchmark_gap

Important rule:

- Support all selected KPIs, not only the first two.

Deliverables:

- Cross-KPI comparison API
- KPI by dimension API
- Correlation API
- Target vs actual API
- Top/bottom API
- Variance API
- Benchmark gap API

## Phase 5: Gold-layer reporting

Materialize the analytics outputs into Gold:

- gold_kpi_results
- gold_dashboard_dataset
- gold_kpi_by_dimension
- gold_kpi_correlation
- gold_target_vs_actual
- gold_top_bottom_segments
- gold_variance_analysis
- gold_benchmark_gap
- gold_dashboard_recommendations
- gold_validation_summary
- gold_kpi_lineage
- gold_export_dataset

Deliverable:

- Gold dashboard endpoint that reads Gold only.

## Phase 6: Dashboard recommendation engine

Implement dashboard recommendation logic.

The engine should recommend:

- KPI cards
- trends
- KPI by dimension
- correlation matrix
- target vs actual
- top/bottom segments
- variance analysis
- benchmark gap
- validation warning panel
- lineage panel

Deliverable:

- GET /api/dashboard/recommendations/{dataset_id}
- recommendations included in Gold dashboard response

## Phase 7: Frontend dashboard upgrade

Add feature-flagged dashboard sections:

- KPI cards
- trend comparison
- KPI by dimension
- correlation matrix
- target vs actual
- top/bottom segments
- variance analysis
- benchmark gap
- dashboard recommendations
- validation warnings
- KPI lineage drawer/modal

Do not remove the old dashboard.

## Phase 8: LiteLLM provider

Add LiteLLM abstraction with:

- mock
- openai/gpt-4o-mini
- anthropic/claude-sonnet-4-20250514

New LLM calls must use this abstraction.

## Phase 9: Gold exports

Generate exports from Gold only:

- Excel
- PowerPoint

Save under:

```text
storage/exports/{dataset_id}/
```

## Phase 10: Verification

Run the v2.1 checklist.

Do not call the task complete unless every mandatory item is done or clearly marked as not possible with explanation.
